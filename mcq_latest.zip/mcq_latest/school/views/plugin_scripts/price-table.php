<link href="<?php echo base_url('assets/css/price-table.css') ?>" rel="stylesheet" media="screen">
